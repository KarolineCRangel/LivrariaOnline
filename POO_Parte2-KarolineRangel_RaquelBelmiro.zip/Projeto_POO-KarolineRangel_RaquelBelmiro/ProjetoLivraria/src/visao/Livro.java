package visao;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

import controle.LivroControle;

@SuppressWarnings({ "serial", "unused" })
public class Livro extends JFrame {
	

	private JTextField jtfId;
	private JTextField jtfAutor;
	private JTextField jtfNome;
	private JTextField jtfEditora;
	private JTextField jtfPreco;
	private JTextField jtfDescricao;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					FormPadrao frame = new FormPadrao();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}


	/**
	 * Create the frame.
	 */
	public Livro() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setTitle("Gerenciamento de Livros");
		setResizable(false);
		setBounds(100, 100, 620, 481);
		getContentPane().setLayout(null);
		
		JPanel panelBotoes = new JPanel();
		panelBotoes.setBounds(0, 0, 618, 78);
		panelBotoes.setBackground(Color.DARK_GRAY);
		getContentPane().add(panelBotoes);
		panelBotoes.setLayout(null);
		
		JButton jbNovo = new JButton("Novo");
		
		jbNovo.setFont(new Font("Dialog", Font.BOLD, 10));
		jbNovo.setBounds(25, 22, 80, 25);
		panelBotoes.add(jbNovo);
		
		JButton jbAlterar = new JButton("Alterar");
		
		jbAlterar.setFont(new Font("Dialog", Font.BOLD, 10));
		jbAlterar.setBounds(115, 22, 80, 25);
		panelBotoes.add(jbAlterar);
		
		
		
		JButton jbExcluir = new JButton("Excluir");
		jbExcluir.setFont(new Font("Dialog", Font.BOLD, 10));
		jbExcluir.setBounds(203, 22, 80, 25);
		panelBotoes.add(jbExcluir);
		
		
		JButton jbSalvar = new JButton("Salvar");
		jbSalvar.setFont(new Font("Dialog", Font.BOLD, 10));
		
		jbSalvar.setBounds(334, 22, 80, 25);

		panelBotoes.add(jbSalvar);
		
		JButton jbCancelar = new JButton("Cancelar");
		jbCancelar.setFont(new Font("Dialog", Font.BOLD, 9));
		jbCancelar.setBounds(421, 23, 80, 25);
		panelBotoes.add(jbCancelar);
		
		jbSalvar.setEnabled(false);
		jbCancelar.setEnabled(false);
		
		jbNovo.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				jbNovo.setEnabled(false);
				jbAlterar.setEnabled(false);
				jbExcluir.setEnabled(false);
				jbSalvar.setEnabled(true);
				jbCancelar.setEnabled(true);
			}
		});
		
		jbAlterar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				jbNovo.setEnabled(false);
				jbAlterar.setEnabled(false);
				jbExcluir.setEnabled(false);
				jbSalvar.setEnabled(true);
				jbCancelar.setEnabled(true);
			}
		});
		
		jbSalvar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
						jbNovo.setEnabled(true);
						jbAlterar.setEnabled(true);
						jbExcluir.setEnabled(true);
						jbSalvar.setEnabled(false);
						jbCancelar.setEnabled(false);
						salvarVisao();
					}
		});
		
		
	
		jbCancelar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
					jbNovo.setEnabled(true);
					jbAlterar.setEnabled(true);
					jbExcluir.setEnabled(true);
					jbSalvar.setEnabled(false);
					jbCancelar.setEnabled(false);
					}
		});
		
		JButton jbFechar = new JButton("Fechar");
		jbFechar.setFont(new Font("Dialog", Font.BOLD, 10));
		jbFechar.setBounds(509, 22, 80, 25);
		panelBotoes.add(jbFechar);
		jbFechar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
			}
		});
		JPanel panelInputs = new JPanel();
		panelInputs.setBackground(Color.DARK_GRAY);
		panelInputs.setBounds(0, 78, 618, 174);
		getContentPane().add(panelInputs);
		panelInputs.setLayout(null);
		
		JLabel lblId = new JLabel("ID");
		lblId.setForeground(Color.WHITE);
		lblId.setBounds(29, 26, 42, 15);
		panelInputs.add(lblId);
		
		jtfId = new JTextField();
		jtfId.setColumns(10);
		jtfId.setBounds(29, 45, 157, 19);
		panelInputs.add(jtfId);
		
		JLabel lblAutor = new JLabel("AUTOR");
		lblAutor.setForeground(Color.WHITE);
		lblAutor.setBounds(29, 76, 58, 15);
		panelInputs.add(lblAutor);
		
		jtfAutor = new JTextField();
		jtfAutor.setColumns(10);
		jtfAutor.setBounds(29, 96, 157, 19);
		panelInputs.add(jtfAutor);
		
		JLabel lblNome = new JLabel("NOME");
		lblNome.setForeground(Color.WHITE);
		lblNome.setBounds(229, 26, 49, 15);
		panelInputs.add(lblNome);
		
		jtfNome = new JTextField();
		jtfNome.setColumns(10);
		jtfNome.setBounds(224, 45, 366, 19);
		panelInputs.add(jtfNome);
		
		JLabel lblEditora = new JLabel("EDITORA");
		lblEditora.setForeground(Color.WHITE);
		lblEditora.setBounds(229, 76, 70, 15);
		panelInputs.add(lblEditora);
		
		jtfEditora = new JTextField();
		jtfEditora.setColumns(10);
		jtfEditora.setBounds(224, 96, 366, 19);
		panelInputs.add(jtfEditora);
		
		JLabel lblPreo = new JLabel("PREÇO");
		lblPreo.setForeground(Color.WHITE);
		lblPreo.setBounds(29, 127, 58, 15);
		panelInputs.add(lblPreo);
		
		jtfPreco = new JTextField();
		jtfPreco.setColumns(10);
		jtfPreco.setBounds(29, 146, 157, 19);
		panelInputs.add(jtfPreco);
		
		JLabel lblDescrio = new JLabel("DESCRIÇÃO");
		lblDescrio.setForeground(Color.WHITE);
		lblDescrio.setBounds(229, 127, 90, 15);
		panelInputs.add(lblDescrio);
		
		jtfDescricao = new JTextField();
		jtfDescricao.setColumns(10);
		jtfDescricao.setBounds(224, 147, 366, 19);
		panelInputs.add(jtfDescricao);
		
		JPanel panelSearch = new JPanel();
		panelSearch.setBounds(0, 249, 618, 236);
		getContentPane().add(panelSearch);
		panelSearch.setBackground(new Color(46, 139, 87));
		panelSearch.setLayout(null);
		
		JLabel label = new JLabel("CONSULTA");
		label.setBounds(33, 27, 83, 15);
		panelSearch.add(label);
		
		jtfConsultaLivro = new JTextField();
		jtfConsultaLivro.setBounds(120, 25, 469, 19);
		panelSearch.add(jtfConsultaLivro);
		jtfConsultaLivro.setColumns(10);
		
		this.setLocationRelativeTo(null);
		



	}
	
	LivroControle livroControle = new LivroControle();
	private JTextField jtfConsultaLivro;

public void salvarVisao() {
	
	livroControle.salvarControle(jtfId.getText(), jtfNome.getText(), jtfAutor.getText(), jtfEditora.getText(), jtfPreco.getText(), jtfDescricao.getText());

		
	}
}
