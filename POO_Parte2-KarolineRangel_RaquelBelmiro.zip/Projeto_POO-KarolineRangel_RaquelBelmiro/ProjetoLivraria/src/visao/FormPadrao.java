package visao;

//import javax.swing.BoxLayout;
//import java.awt.CardLayout;
//import com.jgoodies.forms.layout.FormLayout;
//import com.jgoodies.forms.layout.ColumnSpec;
//import com.jgoodies.forms.layout.RowSpec;
//import javax.swing.GroupLayout;
//import javax.swing.GroupLayout.Alignment;
import java.awt.Color;
import java.awt.EventQueue;
//import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

@SuppressWarnings("serial")
public class FormPadrao extends JFrame {

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					FormPadrao frame = new FormPadrao();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public FormPadrao() {
		

		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setTitle("Gerenciamento de Funcionário");
		setResizable(false);
		setBounds(100, 100, 620, 481);
		getContentPane().setLayout(null);
		
		JPanel panelBotoes = new JPanel();
		panelBotoes.setBounds(0, 0, 614, 78);
		panelBotoes.setBackground(Color.YELLOW);
		getContentPane().add(panelBotoes);
		panelBotoes.setLayout(null);
		
		JButton jbNovo = new JButton("Novo");
		
		jbNovo.setFont(new Font("Dialog", Font.BOLD, 10));
		jbNovo.setBounds(25, 22, 80, 25);
		panelBotoes.add(jbNovo);
		
		JButton jbAlterar = new JButton("Alterar");
		
		jbAlterar.setFont(new Font("Dialog", Font.BOLD, 10));
		jbAlterar.setBounds(115, 22, 80, 25);
		panelBotoes.add(jbAlterar);
		
		
		
		JButton jbExcluir = new JButton("Excluir");
		jbExcluir.setFont(new Font("Dialog", Font.BOLD, 10));
		jbExcluir.setBounds(203, 22, 80, 25);
		panelBotoes.add(jbExcluir);
		
		
		JButton jbSalvar = new JButton("Salvar");
		jbSalvar.setFont(new Font("Dialog", Font.BOLD, 10));
		
		jbSalvar.setBounds(334, 22, 80, 25);

		panelBotoes.add(jbSalvar);
		
		JButton jbCancelar = new JButton("Cancelar");
		jbCancelar.setFont(new Font("Dialog", Font.BOLD, 9));
		jbCancelar.setBounds(421, 23, 80, 25);
		panelBotoes.add(jbCancelar);
		
		jbSalvar.setEnabled(false);
		jbCancelar.setEnabled(false);
		
		jbNovo.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				jbNovo.setEnabled(false);
				jbAlterar.setEnabled(false);
				jbExcluir.setEnabled(false);
				jbSalvar.setEnabled(true);
				jbCancelar.setEnabled(true);
			}
		});
		
		jbAlterar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				jbNovo.setEnabled(false);
				jbAlterar.setEnabled(false);
				jbExcluir.setEnabled(false);
				jbSalvar.setEnabled(true);
				jbCancelar.setEnabled(true);
			}
		});
		
		jbSalvar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
						jbNovo.setEnabled(true);
						jbAlterar.setEnabled(true);
						jbExcluir.setEnabled(true);
						jbSalvar.setEnabled(false);
						jbCancelar.setEnabled(false);
					}
		});
		
		
	
		jbCancelar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
					jbNovo.setEnabled(true);
					jbAlterar.setEnabled(true);
					jbExcluir.setEnabled(true);
					jbSalvar.setEnabled(false);
					jbCancelar.setEnabled(false);
					}
		});
		
		JButton jbFechar = new JButton("Fechar");
		jbFechar.setFont(new Font("Dialog", Font.BOLD, 10));
		jbFechar.setBounds(509, 22, 80, 25);
		panelBotoes.add(jbFechar);
		jbFechar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
			}
		});
		JPanel panelInputs = new JPanel();
		panelInputs.setBackground(Color.YELLOW);
		panelInputs.setBounds(0, 78, 614, 165);
		getContentPane().add(panelInputs);
		panelInputs.setLayout(null);
		
		JPanel panelSearch = new JPanel();
		panelSearch.setBounds(0, 249, 614, 236);
		getContentPane().add(panelSearch);
		panelSearch.setBackground(Color.YELLOW);
		panelSearch.setLayout(new FlowLayout(FlowLayout.CENTER, 15, 5));
		
		this.setLocationRelativeTo(null);
		



	}
}
