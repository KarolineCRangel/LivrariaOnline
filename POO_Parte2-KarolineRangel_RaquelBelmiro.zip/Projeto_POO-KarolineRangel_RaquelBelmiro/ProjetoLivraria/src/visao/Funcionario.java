package visao;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

import controle.FuncionarioControle;

@SuppressWarnings({ "serial", "unused" })
public class Funcionario extends JFrame {
	
//	abstract public void salvarVisao();

	private JTextField jtfCargo;
	private JTextField jtfNome;
	private JTextField jtfCpf;
	private JTextField jtfEmail;
	private JTextField jtfConsultaFuncionario;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					FormPadrao frame = new FormPadrao();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}


	/**
	 * Create the frame.
	 */
	public Funcionario() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setTitle("Gerenciamento de Funcionários");
		setResizable(false);
		setBounds(100, 100, 620, 481);
		getContentPane().setLayout(null);
		
		JPanel panelBotoes = new JPanel();
		panelBotoes.setBounds(0, 0, 618, 78);
		panelBotoes.setBackground(Color.DARK_GRAY);
		getContentPane().add(panelBotoes);
		panelBotoes.setLayout(null);
		
		JButton jbNovo = new JButton("Novo");
		
		jbNovo.setFont(new Font("Dialog", Font.BOLD, 10));
		jbNovo.setBounds(25, 22, 80, 25);
		panelBotoes.add(jbNovo);
		
		JButton jbAlterar = new JButton("Alterar");
		
		jbAlterar.setFont(new Font("Dialog", Font.BOLD, 10));
		jbAlterar.setBounds(115, 22, 80, 25);
		panelBotoes.add(jbAlterar);
		
		
		
		JButton jbExcluir = new JButton("Excluir");
		jbExcluir.setFont(new Font("Dialog", Font.BOLD, 10));
		jbExcluir.setBounds(203, 22, 80, 25);
		panelBotoes.add(jbExcluir);
		
		
		JButton jbSalvar = new JButton("Salvar");
		jbSalvar.setFont(new Font("Dialog", Font.BOLD, 10));
		
		jbSalvar.setBounds(334, 22, 80, 25);

		panelBotoes.add(jbSalvar);
		
		JButton jbCancelar = new JButton("Cancelar");
		jbCancelar.setFont(new Font("Dialog", Font.BOLD, 9));
		jbCancelar.setBounds(421, 23, 80, 25);
		panelBotoes.add(jbCancelar);
		
		jbSalvar.setEnabled(false);
		jbCancelar.setEnabled(false);
		
		jbNovo.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				jbNovo.setEnabled(false);
				jbAlterar.setEnabled(false);
				jbExcluir.setEnabled(false);
				jbSalvar.setEnabled(true);
				jbCancelar.setEnabled(true);
			}
		});
		
		jbAlterar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				jbNovo.setEnabled(false);
				jbAlterar.setEnabled(false);
				jbExcluir.setEnabled(false);
				jbSalvar.setEnabled(true);
				jbCancelar.setEnabled(true);
			}
		});
		
		jbSalvar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
						jbNovo.setEnabled(true);
						jbAlterar.setEnabled(true);
						jbExcluir.setEnabled(true);
						jbSalvar.setEnabled(false);
						jbCancelar.setEnabled(false);
						salvarVisao();
					}
		});
		
		
	
		jbCancelar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
					jbNovo.setEnabled(true);
					jbAlterar.setEnabled(true);
					jbExcluir.setEnabled(true);
					jbSalvar.setEnabled(false);
					jbCancelar.setEnabled(false);
					salvarVisao();

					}
		});
		
		JButton jbFechar = new JButton("Fechar");
		jbFechar.setFont(new Font("Dialog", Font.BOLD, 10));
		jbFechar.setBounds(509, 22, 80, 25);
		panelBotoes.add(jbFechar);
		jbFechar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
			}
		});
		JPanel panelInputs = new JPanel();
		panelInputs.setBackground(Color.DARK_GRAY);
		panelInputs.setBounds(0, 78, 618, 165);
		getContentPane().add(panelInputs);
		panelInputs.setLayout(null);
		
		JLabel lblCpf = new JLabel("CPF");
		lblCpf.setForeground(new Color(255, 255, 255));
		lblCpf.setBounds(30, 12, 42, 15);
		panelInputs.add(lblCpf);
		
		jtfCargo = new JTextField();
		jtfCargo.setBounds(30, 82, 157, 19);
		panelInputs.add(jtfCargo);
		jtfCargo.setColumns(10);
		
		JLabel lblNome = new JLabel("NOME");
		lblNome.setForeground(new Color(255, 255, 255));
		lblNome.setBounds(230, 12, 49, 15);
		panelInputs.add(lblNome);
		
		jtfNome = new JTextField();
		jtfNome.setBounds(225, 31, 366, 19);
		panelInputs.add(jtfNome);
		jtfNome.setColumns(10);
		
		JLabel lblCargo = new JLabel("CARGO");
		lblCargo.setForeground(new Color(255, 255, 255));
		lblCargo.setBounds(30, 62, 58, 15);
		panelInputs.add(lblCargo);
		
		jtfCpf = new JTextField();
		jtfCpf.setColumns(10);
		jtfCpf.setBounds(30, 31, 157, 19);
		panelInputs.add(jtfCpf);
		
		JLabel lblEmail = new JLabel("EMAIL");
		lblEmail.setForeground(new Color(255, 255, 255));
		lblEmail.setBounds(230, 62, 70, 15);
		panelInputs.add(lblEmail);
		
		jtfEmail = new JTextField();
		jtfEmail.setColumns(10);
		jtfEmail.setBounds(225, 82, 366, 19);
		panelInputs.add(jtfEmail);
		
		JPanel panelSearch = new JPanel();
		panelSearch.setBounds(0, 242, 618, 243);
		getContentPane().add(panelSearch);
		panelSearch.setBackground(new Color(46, 139, 87));
		panelSearch.setLayout(null);
		
		JLabel label = new JLabel("CONSULTA");
		label.setBounds(36, 26, 87, 15);
		panelSearch.add(label);
		
		jtfConsultaFuncionario = new JTextField();
		jtfConsultaFuncionario.setBounds(128, 24, 463, 19);
		panelSearch.add(jtfConsultaFuncionario);
		jtfConsultaFuncionario.setColumns(10);
		
		this.setLocationRelativeTo(null);
		



	}
	
	FuncionarioControle funcControle = new FuncionarioControle();
	
	public void salvarVisao() {
		
		funcControle.salvarControle(jtfCpf.getText(), jtfNome.getText(), jtfCargo.getText(), jtfEmail.getText());
		
	}

	
}
