package controle;

import dao.FuncionarioDao;
import interfaces.InterfaceControle;
import modelo.FuncionarioModelo;

public class FuncionarioControle implements InterfaceControle{
	
	FuncionarioModelo FuncModelo = new FuncionarioModelo();
	FuncionarioDao FuncDao = new FuncionarioDao();

	@Override
	public void salvarControle(Object... valor) {
		// TODO Auto-generated method stub
		FuncModelo.setCpf(Integer.parseInt((valor[0]).toString()));
		FuncModelo.setNome((String)valor[1]);
		FuncModelo.setCargo((String)valor[2]);
		FuncModelo.setEmail((String)valor[3]);
		
		FuncDao.salvarDao(FuncModelo);
	
	}

	@Override
	public void excluirControle(int id) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void carregarComboBox(int id) {
		// TODO Auto-generated method stub
		
	}

}