package controle;


import dao.LivroDao;
import interfaces.InterfaceControle;
import modelo.LivroModelo;

public class LivroControle implements InterfaceControle{
	
	LivroModelo livroModelo = new LivroModelo();
	LivroDao livroDao = new LivroDao();

	@Override
	public void salvarControle(Object... valor) {
		// TODO Auto-generated method stub
		
		
		livroModelo.setId(Integer.parseInt((valor[0]).toString()));
		livroModelo.setNome((String)valor[1]);
		livroModelo.setAutor((String)valor[2]);
		livroModelo.setEditora((String)valor[3]);
		livroModelo.setPreco(Float.parseFloat((valor[4]).toString()));
		livroModelo.setDescricao((String)valor[5]);
		livroDao.salvarDao(livroModelo);
		
		

	}

	@Override
	public void excluirControle(int id) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void carregarComboBox(int id) {
		// TODO Auto-generated method stub
		
	}

}
