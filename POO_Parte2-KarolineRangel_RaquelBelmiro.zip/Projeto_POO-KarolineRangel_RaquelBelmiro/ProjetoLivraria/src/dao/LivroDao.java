package dao;

import java.sql.SQLException;

import javax.swing.JComboBox;

import interfaces.InterfaceDao;

public class LivroDao implements InterfaceDao{
	
	public void salvarDao(Object... valor) {
//		LivroModelo livroModelo= (LivroModelo)valor[0];
//		System.out.println("estou no dao vou gravar no bd "+livroModelo.getNome());
	}
	
	public void excluirDao(int id) {}
	
	public void consultarDao(Object... valor) throws SQLException{}

	public void carregarComboBoxDao(JComboBox itens) throws SQLException{}


}
