package dao;

import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.swing.JComboBox;
import javax.swing.JOptionPane;

import interfaces.InterfaceDao;
import modelo.FuncionarioModelo;

	public class FuncionarioDao implements InterfaceDao{
		
		String sql;
		PreparedStatement stm;

		public void salvarDao(Object... valor) {
			
			FuncionarioModelo FuncModelo= (FuncionarioModelo)valor[0];
			
			if(FuncModelo.getCpf() == 0) {
				sql = "INSERT INTO funcionario (cpf) Values (?)";
				
			}else{
				
				sql="UPDATE funcionario SET cpf=? WHERE cpf=?";
			}
			
			try {
				stm = ConexaoBanco.abreConexao().prepareStatement(sql);
				stm.setString(1, FuncModelo.getNome());
				if(FuncModelo.getCpf()>0) stm.setInt(2, FuncModelo.getCpf());
				stm.execute();
				stm.close();
				JOptionPane.showMessageDialog(null, "registro gravado");
			}catch(Exception e){
				JOptionPane.showMessageDialog(null, "erro:"+e);
			}
		}
		
		public void excluirDao(int id) {}
		
		public void consultarDao(Object... valor) throws SQLException{}

		public void carregarComboBoxDao(JComboBox items) throws SQLException{}

	}

