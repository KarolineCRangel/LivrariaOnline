package visao;

import java.awt.EventQueue;

import javax.swing.JInternalFrame;
import javax.swing.JPanel;
import java.awt.BorderLayout;
import java.awt.FlowLayout;
import javax.swing.BoxLayout;
import java.awt.CardLayout;
import com.jgoodies.forms.layout.FormLayout;
import com.jgoodies.forms.layout.ColumnSpec;
import com.jgoodies.forms.layout.RowSpec;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JButton;

public class FormPadrao extends JInternalFrame {

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					FormPadrao frame = new FormPadrao();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public FormPadrao() {
		setBounds(100, 100, 624, 517);
		getContentPane().setLayout(null);
		
		JPanel panelBotoes = new JPanel();
		panelBotoes.setBounds(0, 0, 614, 75);
		panelBotoes.setBackground(Color.YELLOW);
		getContentPane().add(panelBotoes);
		panelBotoes.setLayout(new FlowLayout(FlowLayout.CENTER, 15, 5));
		
		JPanel panelInputs = new JPanel();
		panelInputs.setBackground(Color.YELLOW);
		panelInputs.setBounds(0, 78, 614, 165);
		getContentPane().add(panelInputs);
		panelInputs.setLayout(new FlowLayout(FlowLayout.CENTER, 15, 5));
		
		JPanel panelSearch = new JPanel();
		panelSearch.setBounds(0, 249, 614, 236);
		getContentPane().add(panelSearch);
		panelSearch.setBackground(Color.YELLOW);
		panelSearch.setLayout(new FlowLayout(FlowLayout.CENTER, 15, 5));

	}
}
